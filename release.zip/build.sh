rm -rf node_modules/
npm install --production
zip -r ./release.zip ./
npm install