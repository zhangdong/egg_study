// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportEnsureRequest = require('../../../app/middleware/ensure_request');
import ExportErrorHandler = require('../../../app/middleware/error_handler');

declare module 'egg' {
  interface IMiddleware {
    ensureRequest: typeof ExportEnsureRequest;
    errorHandler: typeof ExportErrorHandler;
  }
}
