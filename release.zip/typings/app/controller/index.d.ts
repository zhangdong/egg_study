// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportMessage = require('../../../app/controller/message');
import ExportUpdate = require('../../../app/controller/update');
import ExportUser = require('../../../app/controller/user');
import ExportWeb = require('../../../app/controller/web');

declare module 'egg' {
  interface IController {
    message: ExportMessage;
    update: ExportUpdate;
    user: ExportUser;
    web: ExportWeb;
  }
}
