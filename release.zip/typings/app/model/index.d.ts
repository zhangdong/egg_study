// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAdmin = require('../../../app/model/admin');
import ExportMessage = require('../../../app/model/message');
import ExportRecordNews = require('../../../app/model/record_news');
import ExportUser = require('../../../app/model/user');

declare module 'egg' {
  interface IModel {
    Admin: ReturnType<typeof ExportAdmin>;
    Message: ReturnType<typeof ExportMessage>;
    RecordNews: ReturnType<typeof ExportRecordNews>;
    User: ReturnType<typeof ExportUser>;
  }
}
