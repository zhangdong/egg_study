// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAdminUser = require('../../../app/service/admin_user');
import ExportGarbage = require('../../../app/service/garbage');
import ExportMessage = require('../../../app/service/message');
import ExportRecordNews = require('../../../app/service/record_news');
import ExportSocketCache = require('../../../app/service/socket_cache');
import ExportTools = require('../../../app/service/tools');
import ExportUser = require('../../../app/service/user');

declare module 'egg' {
  interface IService {
    adminUser: ExportAdminUser;
    garbage: ExportGarbage;
    message: ExportMessage;
    recordNews: ExportRecordNews;
    socketCache: ExportSocketCache;
    tools: ExportTools;
    user: ExportUser;
  }
}
